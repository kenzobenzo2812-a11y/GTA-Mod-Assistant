Demo GT Supercar Add-On v1.2
Author: GTA Mod Assistant Sample
Built for GTA V v1.0.3095+ / v1.0.3411.0

Installation Instructions:
1. Copy democar folder to mods\update\x64\dlcpacks\democar\dlc.rpf
2. Add <Item>dlcpacks:/democar/</Item> to mods\update\update.rpf\common\data\dlclist.xml

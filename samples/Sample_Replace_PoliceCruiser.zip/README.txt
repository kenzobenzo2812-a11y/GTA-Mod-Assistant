Sample LSPD Patrol Cruiser Replacement v1.1
Author: GTA Mod Assistant Demo
Built for GTA V 1.0.3411.0

Installation:
Place police.yft, police_hi.yft, and police.ytd into:
mods\x64e.rpf\levels\gta5\vehicles.rpf\
